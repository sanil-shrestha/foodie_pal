package com.miu.cs544.lab.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Cacheable(true)
@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class Course {

    @Id
    private int id;

    private String title;

    private LocalDate startDate;

    private String professorName;

    public Course(){

    }

    public Course(int id, String title, LocalDate startDate, String professorName){
        this.id = id;
        this.title = title;
        this.startDate = startDate;
        this.professorName = professorName;
        this.students = new ArrayList<>();
    }

    @OneToMany(cascade = CascadeType.PERSIST)
    private List<Student> students;

    public void addStudent(Student student){
        this.students.add(student);
    }

    public void removeStudent(Student student){
        this.students.remove(student);
    }


    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }


    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        return "Main{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", startDate=" + startDate +
                ", ProfessorName='" + professorName + '\'' +
                '}';
    }
}
