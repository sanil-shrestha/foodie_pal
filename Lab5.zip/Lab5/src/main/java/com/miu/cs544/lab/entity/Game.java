package com.miu.cs544.lab.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Version;
import java.util.List;

@Entity
public class Game {

    @Id
    private int id;
    private String title;
    private float price;

    @Version
    private int version;

    @OneToMany
    private List<Review> reviews;

    public Game() {
    }

    public Game(int id, String title, float price, List<Review> reviews) {
        this.id = id;
        this.title = title;
        this.price = price;
        this.reviews = reviews;
    }
}
