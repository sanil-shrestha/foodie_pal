package com.miu.cs544.lab;

import com.miu.cs544.lab.entity.DECourse;
import com.miu.cs544.lab.entity.OnCampusCourse;
import com.miu.cs544.lab.entity.Student;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.logging.Logger;

public class Main {

    private static final Logger LOGGER = Logger.getLogger( Main.class.getName() );

    public static void main(String[] args) {
        LOGGER.info("Running cs544 Lab2");

        var emf = Persistence.createEntityManagerFactory("default");
        var em = emf.createEntityManager();

        var student1 = new Student(1,"Sanil", 3.6f);
        var student2 = new Student(2,"Ramesh", 3.5f);
        var student3 = new Student(3,"Abhnash", 3.7f);
        var student4 = new Student(4,"Roman", 3.9f);

        var course1 = new OnCampusCourse(111, "EA", LocalDate.of(2023, 6, 25), "Prof Najeeb Najeeb", "M219" ,25);
        var course3 = new OnCampusCourse(113, "ASD", LocalDate.of(2023, 5, 24), "Prof. A", "V27", 35);
        var course4 = new OnCampusCourse(114, "MPP", LocalDate.of(2022, 3, 24), "Prof. B", "V24", 40);
        var course5 = new OnCampusCourse(115, "WAP", LocalDate.of(2022, 4, 24), "Prof. C", "V23", 55);
        var course6 = new OnCampusCourse(116, "CLOUD", LocalDate.of(2022, 1, 24), "Prof. D", "V22", 20);
        var course7 = new OnCampusCourse(117, "FPP", LocalDate.of(2022, 8, 24), "Prof. D", "V21", 32);

        var course8 = new DECourse(113, "Database Design", LocalDate.of(2023, 7, 24),  "Prof Brain" ,"Prof. Sridevi");
        course8.addSessionDate(LocalDate.of(2023, 8, 30));
        course8.addSessionDate(LocalDate.of(2023, 9, 12));
        course8.addSessionDate(LocalDate.of(2023, 10, 14));
        course8.addSessionDate(LocalDate.of(2023, 12, 1));

        student1.addCourseAttended(course1);
        student1.addCourseAttended(course8);
        student1.addCourseAttended(course7);
        student1.addCourseAttended(course6);
        student1.addCourseAttended(course5);
        student1.addCourseAttended(course4);
        student1.setCourseAttending(course3);
        course3.addStudent(student1);

        student2.setCourseAttending(course5);
        student3.setCourseAttending(course6);
        student4.setCourseAttending(course7);

        course5.addStudent(student1);
        course6.addStudent(student1);
        course7.addStudent(student1);

        em.getTransaction().begin();
        em.persist(student1);
        em.persist(student2);
        em.persist(student3);
        em.persist(student4);
        em.getTransaction().commit();

        var queryStr = "SELECT distinct s FROM Student s INNER JOIN OnCampusCourse oc " +
                "WHERE oc.capacity > 30 AND s.gpa>3.5";
        var query = em.createQuery(queryStr);

        var coursesCapacityMoreThan30 = query.getResultList();
        LOGGER.info("\n Courses whose capacity is more than 30 \n");

        coursesCapacityMoreThan30.forEach(element -> LOGGER.info(element.toString()));

        em.getTransaction().begin();
        var entity = em.createNamedQuery("Student.CanGraduate", Student.class)
                .getResultList();
        em.getTransaction().commit();
        LOGGER.info("\n Named Query with PESSIMISTIC_READ");

        entity.forEach(element -> LOGGER.info(element.toString()));

        em.close();
        emf.close();

    }
}
