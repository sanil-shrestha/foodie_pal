package com.miu.cs544.lab.entity;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@NamedQuery(
        name="Student.CanGraduate",
        query = "SELECT DISTINCT s from Student s ")
@Cacheable(true)
public class Student {

    @Id
    private int id;

    private String name;

    private float gpa;

    @OneToOne(cascade = CascadeType.PERSIST)
    private Course courseAttending;

    @ManyToMany(cascade = CascadeType.PERSIST)
    private List<Course> courseAttended;

    @Version
    private int version;

    public Student() {

    }

    public Student(int id, String name, float gpa) {
        this.id = id;
        this.name = name;
        this.gpa = gpa;
        this.courseAttending = null;
        this.courseAttended = new ArrayList<>();
    }

    public void addCourseAttended(Course c){
        this.courseAttended.add(c);
    }

    public Course getCourseAttending() {
        return courseAttending;
    }

    public void setCourseAttending(OnCampusCourse course) {
        this.courseAttending = course;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getGpa() {
        return gpa;
    }

    public void setGpa(float gpa) {
        this.gpa = gpa;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", gpa=" + gpa +
                ", courseAttending=" + courseAttending +
                ", courseAttended=" + courseAttended +
                '}';
    }
}
