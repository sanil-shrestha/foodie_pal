package com.miu.cs544.lab.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Review {

    @Id
    private int id;

    private String text;

    @ManyToOne
    private Game game;

    public Review() {

    }
}
