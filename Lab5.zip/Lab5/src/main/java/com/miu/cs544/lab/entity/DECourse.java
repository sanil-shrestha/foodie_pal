package com.miu.cs544.lab.entity;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
public class DECourse extends Course{

    private String examProfessor;

    @ElementCollection
    List<LocalDate> webinarSessionDates;

    public DECourse(int id, String title, LocalDate startDate, String prof, String examProfessor){
        super(id, title, startDate, prof);
        this.examProfessor = examProfessor;
        this.webinarSessionDates = new ArrayList<>();
    }

    public DECourse() {

    }

    public void addSessionDate(LocalDate newDate){
        this.webinarSessionDates.add(newDate);
    }
}
