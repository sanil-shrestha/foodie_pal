package com.miu.cs544.lab.entity;

import jakarta.persistence.Cacheable;
import jakarta.persistence.Entity;
import java.time.LocalDate;

@Cacheable(true)
@Entity
public class OnCampusCourse extends Course{

    private String room;

    private int capacity;

    public OnCampusCourse(int id, String title, LocalDate startDate, String professorName, String room, int cap){
        super(id, title, startDate, professorName);
        this.room = room;
        this.capacity = cap;
    }

    public OnCampusCourse() {}

    @Override
    public String toString() {
        return "OnCampusCourse{" +
                "room='" + room + '\'' +
                ", capacity=" + capacity +
                '}';
    }
}
